(function() {
    'use strict';

    angular.module('SouthernDegree', [
        'ngMaterial'
    ]);
})();